document.addEventListener("DOMContentLoaded", function () {
	var closeTabsButton = document.getElementById("closeTabsButton");

	closeTabsButton.addEventListener("click", function () {
		chrome.runtime.sendMessage({ action: "closeTabsExceptFirst" });
	});
});
