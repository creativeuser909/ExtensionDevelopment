function closeGroupTabs(url) {
	chrome.tabs.query({}, function (tabs) {
		const groupTabs = tabs.filter(
			(tab) => tab.url === url && tab.groupId !== -1
		);
		if (groupTabs.length > 0) {
			chrome.tabs.remove(
				groupTabs.map((tab) => tab.id),
				function () {
					closeTabsExceptFirst();
				}
			);
		} else {
			closeTabsExceptFirst();
		}
	});
}
function closeTabsExceptFirst() {
	chrome.tabs.query({}, function (tabs) {
		for (var i = 1; i < tabs.length; i++) {
			chrome.tabs.remove(tabs[i].id);
		}
	});
}
chrome.alarms.create("autoCloseTabsAlarm", { periodInMinutes: 0.0833 });
chrome.alarms.onAlarm.addListener(function (alarm) {
	if (alarm.name === "autoCloseTabsAlarm") {
		closeGroupTabs("https://sli.ce.it/earn");
	}
});
closeGroupTabs("https://sli.ce.it/earn");